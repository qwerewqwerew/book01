<?php
//변수 conn 에 mysqli_connect(서버주소, mysql사용자아이디, mysql사용자비밀번호, 데이터베이스이름) 할당
$conn = mysqli_connect("localhost", "root", "", "mango_board");
if (!$conn) { //변수conn 이 false 일경우
  echo 'db에 연결하지 못했습니다.' . mysqli_connect_error(); //문자열과 함께 에러메시지 출력함수 실행
} else {
  echo 'db에 접속했습니다'; //성공시 출력할 문자열
}

$number = $_POST['number'];
$user_name = $_POST['name'];
$user_msg = $_POST['message'];
$sql = "UPDATE free_board SET name='$user_name', message='$user_msg' WHERE number=$number";


$result = mysqli_query($conn, $sql);

if ($result === false) {
  echo "수정에 실패했습니다.";
  error_log(mysqli_error($conn));
} else {
  echo "수정을 완료하였습니다.";
}
mysqli_close($conn);
print "<p><a href='index.php'>메인화면으로 돌아가기</a></p>";
?>
</body>

</html>