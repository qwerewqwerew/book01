<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>망고네 자유 게시판</title>
</head>

<body>
  <h1>자유 게시판</h1>
  <h2>삭제결과</h2>

  <?php
  $conn = mysqli_connect("localhost", "root", "", "mango_board");

  if (!$conn) {
    echo 'db에 연결하지 못했습니다.' . mysqli_connect_error();
  } else {
    echo 'db에 접속했습니다!!!';
  }
  $num = $_POST['delnum'];


  //삭제
  $sqlDEL = "DELETE FROM free_board WHERE number = $num";
  mysqli_query($conn, $sqlDEL);


  echo $num . '번째 데이터가 삭제되었습니다.';
  mysqli_close($conn);
  ?>

  <p><a href="index.php">메인화면으로 돌아가기</a></p>

</html>