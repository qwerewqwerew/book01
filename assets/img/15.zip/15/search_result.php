<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>망고네 자유 게시판</title    $conn = mysqli_connect("localhost", "root", "", "mango_board");
>
</head>

<body>
  <h1>자유 게시판</h1>
  <h2>검색결과</h2>
  <ul>
    <?php
    $conn = mysqli_connect("localhost", "root", "", "mango_board");

    if (!$conn) {
      echo 'db에 연결하지 못했습니다.' . mysqli_connect_error();
    } else {
      echo 'db에 접속했습니다!!!';
    }
    //키워드를 저장할 변수 생성
    //post 방식으로 전달된 boardKey 의 값을  user_key 변수에 저장
    $user_bdkey=$_POST['bdKey'];
    //free_board 테이블에서 조건(where)과 같은 데이터 조회 
    //LIKE 는 부분적으로 일치하는 칼럼을 찾을때 사용 
    //php 의 % 는 * 와 같다
    //변수 bdkey 를 포함하는 문자열이 조건

    $sql = "SELECT * FROM free_board WHERE message LIKE '%$user_bdkey%'";

    $result = mysqli_query($conn, $sql);

    $list = '';

    while ($row = mysqli_fetch_array($result)) {

      $list = $list . "<li>{$row['number']}: <a href=\"view.php?number={$row['number']}\">{$row['name']}</a></li>";
    }
    echo $list;
    //조회후 db를 닫는다
    mysqli_close($conn);
    ?>
  </ul>
  <hr />
  <p><a href="index.php">메인화면으로 돌아가기</a></p>
  <hr />
</body>

</html>