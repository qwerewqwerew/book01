<?php
    const admin_name = 'admin@admin.com';
    const password = '1234';
?>