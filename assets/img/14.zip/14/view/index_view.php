<div class="container">
  <header>
    <h1><?= $title; ?></h1>
  </header>
  <main>
    <h2><?= $data; ?></h2>
  </main>
</div>