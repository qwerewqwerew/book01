<?php
function view($name, $data)
{
    global $title;
    require('view/layout_view.php');
}

function get_data()
{
    $fname = CONFIG['data_file'];
    $json = '';
    if (!file_exists($fname)) {
        #file_put_contents($fname,'');
        $handle = fopen("$fname", "w+");
        fclose($handle);
    } else {
        #$json = file_get_contents($fname);
        $handle = fopen("$fname", "r");
        $json = fread($handle, filesize($fname));
        fclose($handle);
    }
    return  $json;
}
