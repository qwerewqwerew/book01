<?php
require('app/functions.php');
require('app/config.php');