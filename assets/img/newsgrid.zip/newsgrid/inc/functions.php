<?php
function authenticate_user($email, $password)
{
    if ($email = user_name && $password == password) {
        return true;
    }
}
/* redirect 함수에 매개변수가 전달되면 */
function redirect($url)
{
    //url 변수의 값으로 페이지 이동
    //"" 주의
    header("Location:$url");
    exit();
}
function user_is_auth()
{
    return isset($_SESSION['email']);
}

function confirm_user_is_auth()
{
    if (!user_is_auth()) {
        redirect('login.php');
        exit();
    }
}
