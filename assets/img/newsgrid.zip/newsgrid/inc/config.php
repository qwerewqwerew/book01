<?php
    const user_name = 'user@user.com';
    const password = '1234';
?>