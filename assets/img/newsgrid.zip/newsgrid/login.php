<?php
/* add */
session_start();
$title = '로그인';
include('inc/header.php');
include('inc/config.php');
require_once('inc/functions.php');

if (user_is_auth()) {
  redirect('index.php');
  exit();
}

if (isset($_POST['login'])) {

  $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
  $password = $_POST['password'];

  if ($email == false) {
    $status = '이메일 형식에 맞게 입력해주세요.';
  }
  if (authenticate_user($email, $password)) {
    $_SESSION['email'] = $email;
    redirect('index.php');
  } else {
    $status = '비밀번호를 확인해주세요.';
  }
}

?>
<form action="" method="POST">
  <p>
    <label for="email">이메일:</label>
    <input type="email" name="email" id="email" autocomplete="off">
  </p>
  <p>
    <label for="password">비밀번호:</label>
    <input type="password" name="password" id="password" >
  </p>
  <p>
    <input type="submit" name="login" value="로그인">
  </p>
</form>
<div>test계정정보:  이메일 user@user.com 비밀번호 1234 입니다</div>

<div class="error">
  <p>
    <?php
    if (isset($status)) {
      echo $status;
    }
    ?>
  </p>
</div>

<?php include('inc/footer.php') ?>