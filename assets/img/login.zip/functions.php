<?php
    function output($value){
        //입력한 형태 그대로 확인하기 위해 pre 태그를 작성
        echo '<pre>';
        //배열의 값을 실제 출력 형태
        print_r($value);
        echo '</pre>';
    }
?>

