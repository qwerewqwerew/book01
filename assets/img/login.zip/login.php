<?php
$title = 'Login';
include('header.php');
require_once('functions.php');
//$_SERVER변수의 요청방식중 post 와 같으면 true
/* if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  output($_POST);
} 
*/
if (isset($_POST['login'])) {
  output($_POST);
  //사용자가 입력한 이메일값을 저장할 $email 변수 생성
  //php의 filter_input으로 이메일유효성 검사
  //INPUT_POST 
  $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
  $password = $_POST['password'];

  if ($email == false) {
    $status = '이메일 형식에 맞게 입력해주세요.';
  }
}

?>
<!-- add -->
<form action="" method="POST">
  <p>
    <label for="email">이메일:</label>
    <input type="text" name="email" id="email" autocomplete="off">
  </p>
  <p>
    <label for="password">비밀번호:</label>
    <input type="password" name="password" id="password">
  </p>
  <p>
    <input type="submit" name="login" value="로그인">
  </p>
</form>

<div class="error">
  <p>
    <?php
    if (isset($status)) {
      echo $status;
    }
    ?>
  </p>
</div>

<?php include('footer.php') ?>