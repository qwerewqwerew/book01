<?php
  require('app/functions.php');
  $title = '안녕하세요';
  view('index',$title);  
?>