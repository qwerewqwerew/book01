<?php
function view($name,$title){
    #global $title;
    #require('view/'.$name.'_view.php');
    require('view/layout_view.php');
}
